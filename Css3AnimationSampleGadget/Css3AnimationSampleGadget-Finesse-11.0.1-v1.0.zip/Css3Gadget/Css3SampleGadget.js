var finesse = finesse || {};
finesse.gadget = finesse.gadget || {};
finesse.container = finesse.container || {};
clientLogs = finesse.cslogger.ClientLogger || {};  // for logging

/**
 * The following comment prevents JSLint errors concerning the logFinesse function being undefined.
 * logFinesse is defined in Log.js, which should also be included by gadget the includes this file.
 */
/*global logFinesse */

/** @namespace */
finesse.modules = finesse.modules || {};
finesse.modules.Css3Gadget = (function ($) {
    var clientlogs;


    /** @scope finesse.modules.Css3Gadget */
    return {

        /**
         * Injects css or js files into DOM dynamically.
         * This is to bypass Shinding's restriction for special chars in CSS 3 files.
         * E.g. @Keyframes
         */
        injectResource : function (url){
             var node = null;

             // url null? do nothing
             if(!url) {
                return;
             }
             // creates script node for .js files
             else if(url.lastIndexOf('.js')=== url.length-3){
                 node = document.createElement("script");
                 node.async = false;
                 node.setAttribute('src', url);
             }
             // creates link node for css files
             else if(url.lastIndexOf('.css')== url.length-4){
                 node = document.createElement("link");
                 node.setAttribute('href', url);
                 node.setAttribute('rel', 'stylesheet');
             }
             // inserts the node into dom
             if(node) {
               document.getElementsByTagName('head')[0].appendChild(node);
             }
         },



        /**
         * Performs all initialization for this gadget
         */
        init : function () {
            var cfg = finesse.gadget.Config;

            clientLogs = finesse.cslogger.ClientLogger;  // declare clientLogs

            gadgets.window.adjustHeight();

            // Initiate the ClientServices and load the user object. ClientServices are
            // initialized with a reference to the current configuration.
            finesse.clientservices.ClientServices.init(cfg, false);

            // Initiate the ClientLogs. The gadget id will be logged as a part of the message
            clientLogs.init(gadgets.Hub, "Initializing Css3 Animation Gadget");


            // Initiate the ContainerServices and add a handler for when the tab is visible
            // to adjust the height of this gadget in case the tab was not visible
            // when the html was rendered (adjustHeight only works when tab is visible)
            containerServices = finesse.containerservices.ContainerServices.init();
            containerServices.addHandler(finesse.containerservices.ContainerServices.Topics.ACTIVE_TAB, function() {
                clientLogs.log("Gadget is now visible");  // log to Finesse logger
                // automatically adjust the height of the gadget to show the html
                gadgets.window.adjustHeight();
            });
            containerServices.makeActiveTabReq();
        }
    };
}(jQuery));