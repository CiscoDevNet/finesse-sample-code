****************************************************************************
Cisco Finesse - CSS 3 Animation Sample Gadget
Cisco Systems, Inc.
http://www.cisco.com/
https://developer.cisco.com/site/finesse
****************************************************************************

I. Disclaimer
-------------------------------------------------------------------------------


   When loading a CSS3 file, the Finesse Desktop Gadget Container restricts
   @keyframes CSS at-rule.

   The CSS3 Animation Sample Gadget is intended to serve as an example
   to handle CSS3 animations in the Finesse Desktop Gadget Container.

   This is only a sample and is NOT intended to be a production quality
   gadget and will not be supported as such.  It is NOT guaranteed to
   be bug free. It is merely provided as a guide for a programmer to see
   how to initialize a gadget and set up handlers for user and dialog updates.
   
   The sample contains the following files:

      FinesseJavaScriptLibrary/
         readme.txt
      Css3Gadget/
         Css3SampleGadget.css
         Css3SampleGadget.js
         Css3SampleGadget.xml

      _readme.txt - This file


   This gadget sample is made available to Cisco partners and customers as
   a convenience to help minimize the cost of Cisco Finesse customizations.
   Please see the readme.txt in the FinesseJavaScriptLibrary folder for
   further information about the Finesse libraries.


II. Requirements
-------------------------------------------------------------------------------
None.

III. Usage
-------------------------------------------------------------------------------

1. SFTP the gadget contents to /3rdpartygadget/root/files
2. Edit layout xml in cfadmin to load the gadget
   <gadget>/3rdpartygadget/files/Css3Gadget/Css3SampleGadget.xml</gadget>
3. Refresh the agent desktop.
4. Animation is applied to Make Call button.

