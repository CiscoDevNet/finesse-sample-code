var finesse = finesse || {};
finesse.gadget = finesse.gadget || {};
finesse.container = finesse.container || {};

/*global logFinesse */

/** @namespace */
finesse.modules = finesse.modules || {};
finesse.modules.SampleGadget = (function ($) {
    var clientLogs, user,

    /**
     * Handler for when the change agent state fails
     * For simplicity, this handler will just log the error.
     * This method also shows how to grab the information
     * from the ApiError event.
     */
    handleChangeStateError = function(error) {
        clientLogs.log("handleChangeStateError(): Got an error while changing state");
        clientLogs.log("ErrorXML: " + error.content);
        clientLogs.log("ErrorData: " + error.object.ApiErrors.ApiError.ErrorData);
        clientLogs.log("ErrorMessage: " + error.object.ApiErrors.ApiError.ErrorMessage);
        clientLogs.log("ErrorType: " + error.object.ApiErrors.ApiError.ErrorType);
    },

    /**
     * Populates the fields in the gadget with data
     */
    populateGadget = function () {
        var currentState = user.getState();

        // Populate the values of the fields
        // from the XML file.
        // Examples of getting data from the User object (GET)
        $("#userId").text(user.getId());
        $("#firstName").text(user.getFirstName());
        $("#lastName").text(user.getLastName());
        if (user.hasSupervisorRole()) {
            $("#userRole").text('Supervisor');
        } else {
            $("#userRole").text('Agent');
        }
        $("#extension").text(user.getExtension());
        $("#userState").text(currentState);
        $("#teamId").text(user.getTeamId());
        $("#teamName").text(user.getTeamName());

        // Displaying the correct state button depending
        // on the user's current state.
        // This button calls the setState (PUT) method.
        // This also includes an example of using the
        // finesse.restservices.User.States enum
        if (currentState === finesse.restservices.User.States.NOT_READY) {
            $("#goReady").show();
            $("#goNotReady").hide();
        } else if (currentState === finesse.restservices.User.States.READY) {
            $("#goNotReady").show();
            $("#goReady").hide();
        } else {
            $("#goNotReady").hide();
            $("#goReady").hide();
        }
        
        // Adjust the height of the gadget so that
        // the gadget doesn't get cut off  
        gadgets.window.adjustHeight();
    },

    /**
     * Handler for all User updates
     * This handler is called every time there is a change
     * to the User object. (e.g. agent state change, team
     * change, name change, etc.)
     */
    handleUserChange = function(userevent) {
        populateGadget();
    },

    /**
     * Handler for the onLoad of a User object.
     * This handler is called when the User object is initially
     * read from the Finesse server. This handler is only called
     * once, so any once only initialization should be done
     * within this function.
     */
    handleUserLoad = function (userevent) {
        populateGadget();
    };

    /** @scope finesse.modules.SampleGadget */
    return {
        /**
         * Sets the user state.
         * This method calls the user setState JavaScript
         * API which internally calls the User - Change Agent State
         * REST API. 
         */
        setUserState : function (state) {            
            // Will let this method be a pass through
            // to the Finesse server. If the agent
            // state change is not valid, it will return
            // an ApiError event.
            //
            // You do not need a success handler because
            // the user onChange handler (handleUserChange)
            // will receive the updated User event.
            user.setState(state, null, {
                error : handleChangeStateError
            });
        },

        /**
         * Performs all initialization for this gadget
         */
        init : function () {
            // Declare the config object
            var cfg = finesse.gadget.Config;

            // Declare the client logger
            clientLogs = finesse.cslogger.ClientLogger;

            // Initiate the ClientServices with the current configuration.
            // Enabling the ClientServices will establish a a BOSH event
            // connection for the logged in user.
            finesse.clientservices.ClientServices.init(cfg);

            // Initiate the ClientLogs.
            // Each log statement will be automatically prefixed
            // with the gadgetId.
            clientLogs.init(gadgets.Hub, "SampleGadget", cfg);

            // Initiate the ContainerServices and add a handler for when the tab is visible.
            // The adjustHeight method only works when the tab is visible, so it is best to 
            // adjust the height of this gadget in case the tab was not visible
            // when the html was rendered.
            containerServices = finesse.containerservices.ContainerServices.init();
            containerServices.addHandler(finesse.containerservices.ContainerServices.Topics.ACTIVE_TAB, function() {
                clientLogs.log("Gadget is now visible");  // log to Finesse logger

                // Adjust the height of this gadget in case the tab was not visible
                // when the html was rendered.
                gadgets.window.adjustHeight();
            });

            // Call the active tab handler from above.
            containerServices.makeActiveTabReq();

            // Create the User object for the logged in user
            // Assign the necessary handlers
            // The onLoad handler is only called once, when the
            // User object is loaded.
            // The onChange handler is called every time there is
            // a change to the User object (when Finesse sends a
            // User notification).
            user = new finesse.restservices.User({
                id: cfg.id, 
                onLoad : handleUserLoad,
                onChange : handleUserChange
            });
        }
    };
}(jQuery));