/**
 * <code>digitalChannelHandler</code> : Javascript handler class for the Finext
 * Digital Channel gadget
 * 
 * @copyright Cisco Systems Confidential Copyright (c) 2018-2019 by Cisco
 *            Systems, Inc. All Rights Reserved.
 * 
 * @group CBABU
 * 
 * @version <table border="1" cellpadding="3" cellspacing="0" width="95%">
 *          <tr bgcolor="#EEEEFF" id="TableSubHeadingColor">
 *          <td width="10%"><b>Date</b></td>
 *          <td width="10%"><b>Author</b></td>
 *          <td width="10%"><b>Version</b></td>
 *          <td width="*"><b>Description</b></td>
 *          </tr>
 *          <tr bgcolor="white" id="TableRowColor">
 *          <td>02-Jul-2014</td>
 *          </tr>
 *          </table>
 * 
 * @since UCCX 12.0
 */
var digitalChannelHandler = (function () {
    var ACTION_TIMEOUT_SECONDS = 30, channelService, popOverService, logger,

        sparkChannelData = {},

        webexChannelData = {},

        getSparkDefaultChannelData = function () {
            return {
                channelId: "SparkChannel",
                label: "Third-party Chat",
                icon: "persistent-chat",
                states: [{
                    menuId: "ready-menu-item",
                    label: "Ready",
                    status: channelService.STATE_STATUS.AVAILABLE
                }, {
                    menuId: "not-ready-menu-item",
                    label: "Not Ready",
                    status: channelService.STATE_STATUS.UNAVAILABLE
                }],
                enable: true,
                curStateMenuId: "not-ready-menu-item",
                curStateLabel: "Not Ready",
                curStateStatus: channelService.STATE_STATUS.UNAVAILABLE,
                logoutDisabled: false,
                iconBadge: channelService.ICON_BADGE_TYPE.NONE,
                hoverText: "",
                allowStateChange: true,
                isPopDisplayed: false,
                popOverId: ""
            };
        },

        getWebexDefaultChannelData = function () {
            return {
                channelId: "WebexChannel",
                label: "Third-party Email",
                icon: "read-email",
                states: [{
                    menuId: "ready-menu-item",
                    label: "Ready",
                    status: channelService.STATE_STATUS.AVAILABLE
                }, {
                    menuId: "not-ready-menu-item",
                    label: "Not Ready",
                    status: channelService.STATE_STATUS.UNAVAILABLE
                }],
                enable: true,
                curStateMenuId: "not-ready-menu-item",
                curStateLabel: "Not Ready",
                curStateStatus: channelService.STATE_STATUS.UNAVAILABLE,
                logoutDisabled: false,
                iconBadge: channelService.ICON_BADGE_TYPE.NONE,
                hoverText: "",
                allowStateChange: true,
                isPopDisplayed: false,
                popOverId: ""
            };
        },

        getStateChangeErrorResponse = function () {
            return {
                status: channelService.STATUS.FAILURE,
                error: {
                    errorCode: "567",
                    errorDesc: "System is temporarily down."
                }
            };
        },

        log = function (msg) {
            msg = "FiNext Mock Gadget: " + msg;
            logger.log(msg);
        },

        _getChannelMenuPayload = function (menuLabel, state1, state2) {
            return {
                label: menuLabel,
                menuItems: [{
                    id: state1.menuId,
                    label: state1.label,
                    iconColor: channelService.STATE_STATUS.AVAILABLE
                }, {
                    id: state2.menuId,
                    label: state2.label,
                    iconColor: channelService.STATE_STATUS.UNAVAILABLE
                }]
            };
        },

        _getChannelConfigPayload = function (icon) {
            return {
                actionTimeoutInSec: ACTION_TIMEOUT_SECONDS,
                icons: [{
                    type: channelService.ICON_TYPE.COLLAB_ICON,
                    value: icon
                }]
            };
        },

        _getChannelStatePayload = function (channelState) {
            return {
                label: channelState.label,
                currentState: channelState.curStateLabel,
                iconColor: channelState.curStateStatus,
                enable: channelState.enable,
                logoutDisabled: channelState.logoutDisabled,
                iconBadge: channelState.iconBadge ? channelState.iconBadge
                    : channelService.ICON_BADGE_TYPE.NONE,
                hoverText: channelState.hoverText
            };
        },

        _addDisableClass = function (channelId, elementId) {
            var element = document.getElementById(channelId + elementId);
            element.classList.add("disable");
        },

        _removeDisableClass = function (channelId, elementId) {
            var element = document.getElementById(channelId + elementId);
            element.classList.remove("disable");
        },

        _updateButtons = function (channelData) {
            var channelId = (channelData.channelId === 'SparkChannel') ? 'ch1'
                : 'ch2';
            // channel added
            _addDisableClass(channelId, "add");
            // enable the remove button
            _removeDisableClass(channelId, "remove");

            // enable and disable buttons
            if (channelData.enable) {
                _addDisableClass(channelId, "enable");
                _removeDisableClass(channelId, "disable");
                // ready button
                if (channelData.curStateMenuId === 'ready-menu-item') {
                    _addDisableClass(channelId, "ready");
                } else {
                    _removeDisableClass(channelId, "ready");
                }
                // not ready button
                if (channelData.curStateMenuId === 'not-ready-menu-item') {
                    _addDisableClass(channelId, "notready");
                } else {
                    _removeDisableClass(channelId, "notready");
                }
            } else {
                _removeDisableClass(channelId, "enable");
                _addDisableClass(channelId, "disable");
                _addDisableClass(channelId, "ready");
                _addDisableClass(channelId, "notready");

            }

            // error button
            if (channelData.iconBadge === channelService.ICON_BADGE_TYPE.NONE) {
                _removeDisableClass(channelId, "error");
            } else {
                _addDisableClass(channelId, "error");
            }

            if (channelData.isPopDisplayed === true) {
                _addDisableClass(channelId, "showpop");
                _removeDisableClass(channelId, "hidepop");
            } else {
                _addDisableClass(channelId, "hidepop");
                _removeDisableClass(channelId, "showpop");
            }

            // clear button
            _removeDisableClass(channelId, "clear");
        },

        _updateChannel = function (channelData, onSuccess, onFailure) {
            var channelStateData = _getChannelStatePayload(channelData);
            var payload = {
                channelState: channelStateData
            };

            log("Update Channel Id: " + channelData.channelId + ", Payload: "
                + JSON.stringify(payload));

            channelService.updateChannel(channelData.channelId, payload, onSuccess,
                onFailure);
            _updateButtons(channelData);
        },

        _updateChannelForStateChange = function (channelId, selectedMenuId) {
            var channelData = channelId === 'SparkChannel' ? sparkChannelData
                : webexChannelData;
            // own menu handling
            channelData.states.forEach(function (state) {
                if (state.menuId === selectedMenuId) {
                    channelData.curStateMenuId = state.menuId;
                    channelData.curStateLabel = state.label;
                    channelData.curStateStatus = state.status;
                    channelData.logoutDisabled = state.menuId === 'ready-menu-item';
                    _updateChannel(channelData);
                    return;
                }
            });
        },

        _menuHandler = function (channelId, selectedMenuId, onSuccess, onError) {
            log("Menu Selection Request received from channel id:  " + channelId
                + ", Payload: " + selectedMenuId);
            if (selectedMenuId) {
                var channelData = channelId === 'SparkChannel' ? sparkChannelData
                    : webexChannelData;
                var allowStateChange = channelData.allowStateChange;
                var isAllStateChangeRequest = false;
                // ALL menu handling
                if (selectedMenuId.toUpperCase() === 'ALL_READY') {
                    selectedMenuId = channelData.states[0].menuId;
                    isAllStateChangeRequest = true;
                } else if (selectedMenuId.toUpperCase() === 'ALL_NOT_READY') {
                    selectedMenuId = channelData.states[1].menuId;
                    isAllStateChangeRequest = true;
                }
                if (selectedMenuId === channelData.curStateMenuId) {
                    log("Requested state is same as the underlying channel state.");
                    onSuccess({
                        channelId: channelId,
                        status: channelService.STATUS.SUCCESS
                    });
                } else {
                    if (isAllStateChangeRequest === false) {
                        channelData.allowStateChange = !channelData.allowStateChange;
                    }
                    setTimeout(
                        function () {
                            if (allowStateChange || isAllStateChangeRequest) {
                                onSuccess({
                                    channelId: channelId,
                                    status: channelService.STATUS.SUCCESS
                                });
                                _updateChannelForStateChange(channelId,
                                    selectedMenuId);
                            } else {
                                var errorPayload = getStateChangeErrorResponse();
                                errorPayload.channelId = channelId;
                                onError(errorPayload);
                            }
                        }, 3000);
                }
            }
        },

        _updateButtonsOnRemove = function (channelId) {
            channelId = (channelId === 'SparkChannel') ? 'ch1' : 'ch2';
            _removeDisableClass(channelId, "add");
            _addDisableClass(channelId, "remove");
            _addDisableClass(channelId, "ready");
            _addDisableClass(channelId, "notready");
            _addDisableClass(channelId, "enable");
            _addDisableClass(channelId, "disable");
            _addDisableClass(channelId, "error");
            _addDisableClass(channelId, "clear");
            _addDisableClass(channelId, "showpop");
            _addDisableClass(channelId, "hidepop");
        },

        _addChannel = function (channelData, onSuccess, onFailure) {

            var menuConfigData = _getChannelMenuPayload(channelData.label,
                channelData.states[0], channelData.states[1]);
            var channelConfigData = _getChannelConfigPayload(channelData.icon);
            var channelStateData = _getChannelStatePayload(channelData);

            var data = {
                menuConfig: menuConfigData,
                channelConfig: channelConfigData,
                channelState: channelStateData
            };
            log("Add Channel Data: " + JSON.stringify(data));

            channelService.addChannel(channelData.channelId, data, _menuHandler,
                onSuccess, onFailure);
            _updateButtons(channelData);
        },

        _getBannerData = function (channelData) {
           
            var bannerData = {
                icon: {
                    type: channelService.ICON_TYPE.COLLAB_ICON,
                    value: channelData.icon
                },
                content: [
                    {
                        "name": "Customer Name",
                        "value": "Michael Littlefoot"
                    },
                    {
                        "name": "Phone Number",
                        "value": "+1-408-567-789"
                    },
                    {
                        "name": "Account Number",
                        "value": "23874567923"
                    },
                    {
                        "name": "Problem",
                        "value": "I have some problem with my debit card. I am not able to transact online. Can you help on this."
                    }
                ]
            };
            if(channelData.channelId === "WebexChannel") {
                bannerData.content = [
                    {
                        "name": "Customer",
                        "value": "michaellittlefoot@gmail.com"
                    },
                    {
                        "name": "Subject",
                        "value": "Facing issue with online transaction."
                    }
                ];
            }
            return bannerData;
        },

        _getTimerData = function (channelId) {
            const timerData =  {
                displayTimeoutInSecs: 10,
                display: (channelId === "SparkChannel")
            };
            if(channelId === "SparkChannel"){
                timerData.counterType = popOverService.COUNTER_TYPE.COUNT_DOWN;
            }
            return timerData;
        },

        _getActionData = function (channelId) {
            const actionData = {};
            if (channelId === "SparkChannel") {
                actionData.dismissible = false;
                actionData.buttons = [{
                    id: "Join",
                    label: "Accept",
                    type: "Affirm",
                    hoverText: ""
                }];
            } else {
                actionData.dismissible = true;
            }
            return actionData;
        },
        _popOverCallBack = function (response) {
            log("popOverCallBack:Received popover callback with response " + JSON.stringify(response));
            if (sparkChannelData.isPopDisplayed && response.popoverId === sparkChannelData.popOverId) {
                sparkChannelData.isPopDisplayed = false;
                sparkChannelData.popOverId = '';
                _updateButtons(sparkChannelData);
            } else if (webexChannelData.isPopDisplayed && response.popoverId === webexChannelData.popOverId) {
                webexChannelData.isPopDisplayed = false;
                webexChannelData.popOverId = '';
                _updateButtons(webexChannelData);
            }
        },

        _removeChannel = function (channelId, onSuccess, onFailure) {
            log("Remove Channel Id: " + channelId);

            channelService.removeChannel(channelId, onSuccess, onFailure);
        };

    return {
        initialize: function () {
            var containerService = finesse.containerservices.ContainerServices
                .init();
            channelService = finesse.digital.ChannelService
                .init(containerService);
            logger = finesse.cslogger.ClientLogger;
            logger.init(gadgets.Hub, 'MockGadget');
            finesse.clientservices.ClientServices.setLogger(logger);
            popOverService = finesse.containerservices.PopoverService.init(containerService);

            sparkChannelData = getSparkDefaultChannelData();
            _removeChannel(sparkChannelData.channelId);
            _updateButtonsOnRemove(sparkChannelData.channelId);

            webexChannelData = getWebexDefaultChannelData();
            _removeChannel(webexChannelData.channelId);
            _updateButtonsOnRemove(webexChannelData.channelId);

            gadgets.window.adjustHeight(360);
        },

        handleSparkShowPop: function () {
            const channelId = sparkChannelData.channelId;
            sparkChannelData.popOverId = popOverService.showPopover(_getBannerData(sparkChannelData), _getTimerData(channelId), _getActionData(channelId), _popOverCallBack);
            sparkChannelData.isPopDisplayed = true;
            _updateChannel(sparkChannelData);

        },

        handleSparkHidePop: function () {
            popOverService.dismissPopover(sparkChannelData.popOverId);
            sparkChannelData.isPopDisplayed = false;
            _updateChannel(sparkChannelData);

        },

        handleWebexShowPop: function () {
            const channelId = webexChannelData.channelId;
            webexChannelData.popOverId = popOverService.showPopover(_getBannerData(webexChannelData), _getTimerData(channelId), _getActionData(channelId), _popOverCallBack);
            webexChannelData.isPopDisplayed = true;
            _updateChannel(webexChannelData);

        },

        handleWebexHidePop: function () {
            popOverService.dismissPopover(webexChannelData.popOverId);
            webexChannelData.isPopDisplayed = false;
            _updateChannel(webexChannelData);

        },

        handleSparkAddClick: function () {
            sparkChannelData = getSparkDefaultChannelData();
            _addChannel(sparkChannelData);
        },

        handleSparkRemoveClick: function () {
            var channelId = sparkChannelData.channelId;
            _removeChannel(channelId);
            _updateButtonsOnRemove(channelId);
        },

        handleSparkReadyClick: function () {
            sparkChannelData.curStateMenuId = sparkChannelData.states[0].menuId;
            sparkChannelData.curStateLabel = sparkChannelData.states[0].label;
            sparkChannelData.curStateStatus = sparkChannelData.states[0].status;
            sparkChannelData.logoutDisabled = true;
            _updateChannel(sparkChannelData);
        },

        handleSparkNotReadyClick: function () {
            sparkChannelData.curStateMenuId = sparkChannelData.states[1].menuId;
            sparkChannelData.curStateLabel = sparkChannelData.states[1].label;
            sparkChannelData.curStateStatus = sparkChannelData.states[1].status;
            sparkChannelData.logoutDisabled = false;
            _updateChannel(sparkChannelData);
        },

        handleSparkEnableClick: function () {
            sparkChannelData.enable = true;
            sparkChannelData.logoutDisabled = sparkChannelData.curStateMenuId === 'ready-menu-item';
            _updateChannel(sparkChannelData);
        },

        handleSparkDisableClick: function () {
            sparkChannelData.enable = false;
            sparkChannelData.hoverText = "Third-party chat is Disabled.";
            sparkChannelData.logoutDisabled = false;
            _updateChannel(sparkChannelData);
        },

        handleSparkErrorClick: function () {
            sparkChannelData.iconBadge = "error";
            sparkChannelData.hoverText = "System is temporarily down. ";
            _updateChannel(sparkChannelData);
        },

        handleSparkClearClick: function () {
            sparkChannelData = getSparkDefaultChannelData();
            _updateChannel(sparkChannelData);
        },

        handleWebexAddClick: function () {
            webexChannelData = getWebexDefaultChannelData();
            _addChannel(webexChannelData);
        },

        handleWebexRemoveClick: function () {
            var channelId = webexChannelData.channelId;
            _removeChannel(channelId);
            _updateButtonsOnRemove(channelId);
        },

        handleWebexReadyClick: function () {
            webexChannelData.curStateMenuId = webexChannelData.states[0].menuId;
            webexChannelData.curStateLabel = webexChannelData.states[0].label;
            webexChannelData.curStateStatus = webexChannelData.states[0].status;
            webexChannelData.logoutDisabled = true;
            _updateChannel(webexChannelData);
        },

        handleWebexNotReadyClick: function () {
            webexChannelData.curStateMenuId = webexChannelData.states[1].menuId;
            webexChannelData.curStateLabel = webexChannelData.states[1].label;
            webexChannelData.curStateStatus = webexChannelData.states[1].status;
            webexChannelData.logoutDisabled = false;
            _updateChannel(webexChannelData);
        },

        handleWebexEnableClick: function () {
            webexChannelData.enable = true;
            webexChannelData.logoutDisabled = webexChannelData.curStateMenuId === 'ready-menu-item';
            _updateChannel(webexChannelData);
        },

        handleWebexDisableClick: function () {
            webexChannelData.enable = false;
            webexChannelData.hoverText = "Third-party email is Disabled.";
            webexChannelData.logoutDisabled = false;
            _updateChannel(webexChannelData);
        },

        handleWebexErrorClick: function () {
            webexChannelData.iconBadge = "error";
            webexChannelData.hoverText = "System is temporarily down. ";
            _updateChannel(webexChannelData);
        },

        handleWebexClearClick: function () {
            webexChannelData = getWebexDefaultChannelData();
            _updateChannel(webexChannelData);
        }
    };

}());