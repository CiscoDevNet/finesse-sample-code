****************************************************************************
Cisco Finesse - External REST API Sample Gadget
Cisco Systems, Inc.
http://www.cisco.com
https://developer.cisco.com/site/finesse
****************************************************************************

I. Disclaimer
-------------------------------------------------------------------------------

   The External REST API Sample Gadget is intended to serve as an example of 
   how to call an external REST API using gadgets.io.makeRequest().
      
   This is only a sample and is NOT intended to be a production quality
   gadget and will not be supported as such.  It is NOT guaranteed to
   be bug free. It is merely provided as a guide for a programmer to see
   how to format and pass in the necessary parameters for the
   gadgets.io.makeRequest().
   
   The sample contains the following files:

      FinesseJavaScriptLibrary/
         readme.txt
      ExternalRestApi/
         ExternalRestApiSampleGadget.css
         ExternalRestApiSampleGadget.js
         ExternalRestApiSampleGadget.xml
      _readme.txt - This file

   This gadget sample is made available to Cisco partners and customers as
   a convenience to help minimize the cost of Cisco Finesse customizations.
   Please see the readme.txt in the FinesseJavaScriptLibrary folder for
   futher information about the Finesse libraries.


II. Requirements
-------------------------------------------------------------------------------

An external REST API to be called when a call arrives.


III. Usage
-------------------------------------------------------------------------------

1. Go to the handleNewDialog function and modify the variable url to the URL of
   the external REST API you want to call when a new call arrives.
2. Modify the "method" to the HTTP method of the external
   REST API.
3. If the external REST API requires a request body, uncomment the line of code
   that that sets the variable contentBody. Then, populate this variable with
   the content body of the external REST API. This variable is expected to be a
   string. So if the content body is a JSON object, make sure to convert it into
   a string.

   Also, uncomment the line of code that adds the contentBody to the options
   object as well as the line that adds the contentType. Then, modify the value
   of the contentType to the contentType of the external REST API.
4. If the external REST API requires an authorization header, uncomment the line
   of code that adds the authorization to the options object. If the
   authorization type is Basic Auth, then you can skip to the next step. If not,
   generate the authorization using the appropriate utility (not included) and
   change the authorization value to the one you generated.
5. Upload the sample gadget to the webserver.
6. Add the sample gadget to the desktop layout.
7. Log in the agent/supervisor and view the sample gadget.