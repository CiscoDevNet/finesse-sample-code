Cisco Finesse non-Gadget Code with Strophe and Websocket Sample

------------------------------------------------------------------------------
1) INTRODUCTION
------------------------------------------------------------------------------
The sample presents a page allowing the ability to sign in/out, query for and 
change agent state, and perform basic call control operations.
The example page implements the logic to connect to a XMPP server using
the Strophe Library to receive events. All responses and events will simply 
print to the debugger console.

------------------------------------------------------------------------------
2) DISCLAIMER
------------------------------------------------------------------------------

This is only a sample and is NOT intended to be production quality and will not
be supported as such.  It is NOT guaranteed to be bug free. It is merely provided
as a guide for a programmer to see how to use the Strophe Library and
jQuery to make Finesse REST API requests and process the Finesse notifications.

------------------------------------------------------------------------------
3) DEPENDENCIES
------------------------------------------------------------------------------
jQuery: The code requires jQuery JavaScript library to be imported. The library
is used to simplify client-side scripting of the DOM and used to make Ajax
requests. The HTML page currently uses jQuery 1.9.1.

Strophe: Strophe Library is the XMPP library
used to connect to the Notification Service to receive events. The sample page
depends on the library be imported. Developers can have a choice of using this
library or utilizing their own. Download the library from
https://strophe.im/strophejs/

Strophe Ping Plugin: strophe.ping.js is a plugin to provide XMPP Ping (XEP-0199).

Strophe Pubsub Plugin: strophe.pubsub.min.js is a plugin that provides publish/subscribe
functionality in the browser.

------------------------------------------------------------------------------
4) FILES
------------------------------------------------------------------------------
- index.html: The HTML UI.

- finessenongadget.js: An example object library which expose interfaces to make
requests to Finesse Web Services API. Uses jQuery to make the Ajax request.

- sample.js: Controller file imported to bind actions to buttons, create
dependent objects, and manage UI functions.

------------------------------------------------------------------------------
5) DEPLOYMENT
------------------------------------------------------------------------------
Developers who wish to use the sample page should be aware of the same-origin
policy. A page loaded in a browser can only make Ajax requests to the server
which is hosting the original web content. Since the sample page is loading
from a webserver outside of the Cisco Finesse server, the page cannot make
direct Ajax request to the Web Service or Notification Service. A common
deployment solution is to set up a HTTP proxy on the developer web server
which can proxy all BOSH connections and HTTP request to the Cisco Finesse
server.

Note: Refer the VPN less feature available with Finesse 12.6 ES01 for a sample
reverse proxy configuration. Refer NonGadgetSample for an older sample Apache
proxy configurations.

------------------------------------------------------------------------------
6) CONTACT US
------------------------------------------------------------------------------
Questions? Visit the DevNet Finesse Microsite and post your questions in the forums.
    http://developer.cisco.com/site/finesse/