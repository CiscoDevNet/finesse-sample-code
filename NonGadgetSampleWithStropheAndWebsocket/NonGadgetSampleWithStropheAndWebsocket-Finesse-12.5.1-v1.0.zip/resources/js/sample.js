/**
 * Controller JavaScript to manage the functions of the page. The init function
 * is located near the bottom, which will bind actions to all buttons.
 */

var

    //Private finesse object.
    _finesse,

    //Store agent information
    _username, _password, _extension, _domain, _login,

    //Private reference to strophe eventing object.
    _xmppClient;

/**
 * Reset the sample page back to a signed out state.
 */
function _reset() {
    //Clear console.
    $("#console-area").val("");

    //Show sign in boxes.
    $("#div-signin").show();

    //Hide all API actions DIV until successful sign in.
    $("#actions").hide();

    //Hide agent info DIV until successful sign in.
    $("#div-signout").hide();

    //Reset agent info data.
    $("#span-agent-info").html("");

    //Clear the dial number field.
    $("#field-call-control-make-dialnum").val("");

    //Clear the callid field.
    $("#field-call-control-callid").val("");
}

function replaceAll(str, stringToReplace, replaceWith) {
    var result = str,
        index = 1;
    while (index > 0) {
        result = result.replace(stringToReplace, replaceWith);
        index = result.indexOf(stringToReplace);
    }
    return result;
}

/**
 * Print text to console output.
 */
function print2Console(type, data) {
    console.log('print2Console', type, data);
    var date = new Date(),
        str = data.toString(),
        consoleArea = $("#console-area");

    str = replaceAll(str, "&lt;", "<");
    str = replaceAll(str, "&gt;", ">");

    //Convert data object to string and print to console.
    consoleArea.val(consoleArea.val() + "[" + date.getTime() + "] [" +
        type + "] " + str + "\n\n");

    //Scroll to bottom to see latest.
    consoleArea.scrollTop(consoleArea[0].scrollHeight);
    consoleArea = null;
}

function onClientError(rsp) {
    print2Console("ERROR " + rsp);
}

/**
 * Event handler that prints events to console.
 */
function _eventHandler(data) {
    var messageText = data.textContent;
    print2Console("EVENT", messageText);
    // try to get the callid
    var callid = $(data).find("id");
    if (callid.text() !== "") {
        $("#field-call-control-callid").val(callid.text());
    }
    callid = null;
    return true;
}

function _presenceHandler(data) {
    print2Console("EVENT", data.textContent);
    // try to get the callid
    var callid = $(data).find("id");
    if (callid.text() !== "") {
        $("#field-call-control-callid").val(callid.text());
    }
    callid = null;
    return true;
}

function _onConnect(status) {
    console.log("_onConnect() - XMPP client onCONNECT fired");
    // THESE STATUS CODES ARE SELF EXPLANATORY, for more info check the official documentation of Strophe Library.
    if (status === Strophe.Status.ERROR) {
        console.log("_onConnect() - XMPP client about to reset because of status:" + Strophe.Status.ERROR);
    } else if (status === Strophe.Status.AUTHFAIL) {
        console.log("_onConnect() - XMPP client about to reset because of status:" + Strophe.Status.AUTHFAIL);
    } else if (status === Strophe.Status.CONNECTED) {

        _xmppClient.addHandler(_eventHandler, null, 'message', null, null, null);
        _xmppClient.addHandler(_presenceHandler, null, 'presence', null, null, null);
        // We send online presense to the server. (pub sub concept)
        _xmppClient.send($pres().tree());

        // To keep the user session alive on Openfire
        setInterval(function () {
            _xmppClient.ping.ping(_domain,
                function () {},
                function () {}, 10000);
        }, 10000);


        // signing in the Finesse agent when the connection is established Successfully.
        _finesse.signIn(_username, _extension, true, _signInHandler, _signInHandler);
    }
}
/**
 * Establish websocket connection using the strophe library.
 */
function _eventConnect() {
    console.log("_eventConnect - ID:" + _username + ", domain:" + _domain + ", resource:" + _extension);

    //Construct JID with username and domain.
    var jid = _username + "@" + _domain + "/" + _extension,
        scheme = "",
        bindURL = "";
    console.log("_eventConnect - XMPP client JID for connection = " + jid);
    scheme = window.location.protocol === "https:" ? "wss:" : "ws:";
    bindURL = "/ws/";
    // Connection URL for websocket
    var connectURL = scheme + "//" + window.location.host + bindURL;
    console.log("_eventConnect - XMPP client connect url = " + connectURL);

    console.log("_eventConnect - Initialize Strophe XMPP client");
    //Create Strophe connection object.
    _xmppClient = new Strophe.Connection(connectURL);
    console.log("_eventConnect - Strophe XMPP client created");

    console.log("_eventConnect - Calling Strophe XMPP connect");
    //Connect to Websocket connection.
    _xmppClient.connect(jid, _password, _onConnect);
}

/**
 * Disconnects from the BOSH connection.
 */
function _eventDisconnect() {
    if(_xmppClient) {
        _xmppClient.reset();
    }
}

/**
 * Generic handler that prints response to console.
 */
function _handler(data, statusText, xhr) {
    if (xhr) {
        print2Console("RESPONSE", xhr.status);
    } else {
        print2Console("RESPONSE", data);
    }
}

/**
 * GetState handler that prints response to console.
 */
function _getStateHandler(data, statusText, xhr) {
    print2Console("RESPONSE", xhr.responseText);
}

/**
 * Handler for the make call that will validate the response and automatically
 * store the call id retrieve from the response data.
 */
function _makeCallHandler(data, statusText, xhr) {
    print2Console("Make call RESPONSE", statusText);

    //Validate success.
    if (statusText === "success") {
        $("#field-call-control-callid").val("");
    }
}

/**
 * Sign in handler. If successful, hide sign in forms, display actions, and
 * connect to BOSH channel to receive events.
 */
function _signInHandler(data, statusText, xhr) {
    print2Console("Sign in RESPONSE", xhr.status);

    //Ensure success.
    if (xhr.status === 202) {
        //Hide signin forms and show actions.
        $("#div-signin").hide();
        $("#actions").show();
        $("#div-signout").show();
        $("#span-agent-info").html("Logged in as <b>" + _username + "</b> with extension <b>" + _extension + "</b>");
    }
}

function _signOutHandler(data, statusText, xhr) {
    print2Console("Sign out RESPONSE", xhr.status);

    //Ensure success.
    if (xhr.status === 202) {
        // Disconnect from getting events
        _eventDisconnect();

        // Clean up the values of objects
        _reset();
        _username = null;
        _password = null;
        _extension = null;
        _domain = null;

        // Clean up the Finesse object
        _finesse = null;

        // Reload the page after successful sign out.
        // go to logout.jsp
        window.location.reload();
    }
}

/**
 * Init function. Wait until document is ready before binding actions to buttons
 * on the page.
 */
$(document).ready(function () {
    //Reset UI to sign out state.
    _reset();

    //Binds the button to clear the console output box.
    $("#button-clear-console").click(function () {
        $("#console-area").val("");
    });

    /** Bind all buttons to actions **/

    // SYSINFO button
    $("#form-sysinfo").submit(function () {
        _finesse.sysInfo(_handler, _handler);
    });

    //SIGNIN button
    $("#form-agent-signin").submit(function () {
        //Grabs the credentials from the input fields.
        _username = $("#field-agentid").val();
        _password = $("#field-password").val();
        _extension = $("#field-extension").val();
        _domain = $("#field-domain").val();

        //Check non-empty fields
        if (!_username || !_password || !_extension || !_domain) {
            alert("Please enter valid domain and credentials.");
        } else {
            login = true;

            //Create Finesse object and sign in user. On successful sign in, a
            //handler will be invoked to present more API options in UI.

            _finesse = new Finesse(_username, _password);

            _eventConnect();
        }

        return false;
    });

    //SIGNOUT button
    $("#button-signout").click(function () {
        _finesse.signOut(_username, _extension, null, _signOutHandler, _signOutHandler);
    });

    //GET AGENT STATE button
    $("#button-get-agent-state").click(function () {
        _finesse.getState(_username, _getStateHandler, _handler);
    });

    //CHANGE AGENT STATE READY button
    $("#button-change-agent-state-ready").click(function () {
        var newState = "READY"
        if (newState) {
            _finesse.changeState(_username, newState, null, _handler, _handler);
        }
    });

    //CHANGE AGENT STATE NOT READY button
    $("#button-change-agent-state-notready").click(function () {
        var newState = "NOT_READY"
        if (newState) {
            _finesse.changeState(_username, newState, null, _handler, _handler);
        }
    });

    //MAKE CALL button
    $("#form-call-control-make").submit(function () {
        var dialNum = $("#field-call-control-make-dialnum").val();
        _finesse.makeCall(dialNum, _extension, _makeCallHandler, _handler);
        return false;
    });

    //ANSWER CALL button
    $("#button-call-control-answer").click(function () {
        var callId = $("#field-call-control-callid").val();
        _finesse.answerCall(callId, _extension, _handler, _handler);
    });

    //HOLD CALL button
    $("#button-call-control-hold").click(function () {
        var callId = $("#field-call-control-callid").val();
        _finesse.holdCall(callId, _extension, _handler, _handler);
    });

    //RETRIEVE CALL button
    $("#button-call-control-retrieve").click(function () {
        var callId = $("#field-call-control-callid").val();
        _finesse.retrieveCall(callId, _extension, _handler, _handler);
    });

    //DROP CALL button
    $("#button-call-control-drop").click(function () {
        var callId = $("#field-call-control-callid").val();
        _finesse.dropCall(callId, _extension, _handler, _handler);
    });
});