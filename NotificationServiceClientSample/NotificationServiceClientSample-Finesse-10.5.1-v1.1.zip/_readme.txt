Sample Client to connect to Notification Service

------------------------------------------------------------------------------
1) INTRODUCTION
------------------------------------------------------------------------------
This program can be used as a reference to write the external client in any 
language to connect to the Cisco Finesse Notification Service.

------------------------------------------------------------------------------
2) DISCLAIMER
------------------------------------------------------------------------------

This is only a sample and is NOT intended to be production quality and will not
be supported as such.  It is NOT guaranteed to be bug free. It is merely provided
as a guide for a programmer to connect to the Finesse Notification Service.

------------------------------------------------------------------------------
3) DEPENDENCIES
------------------------------------------------------------------------------
smack-3.4.1.jar - Smack is an Open Source XMPP (Jabber) client library for 
instant messaging and presence. This library provides the client side functionality 
as specified in the core XMPP specifications as related to the client side of 
said specifications.

smackx-3.4.1.jar - Smack extensions. Classes and methods that implement support 
for the various XMPP XEPs (Multi-User Chat, PubSub, …) and other XMPP extensions

------------------------------------------------------------------------------
4) FILES
------------------------------------------------------------------------------
- SampleXMPPClient.java: Sample Java program which has step by step process to
connect to the Notification Service and receive XML events.

------------------------------------------------------------------------------
5) Usage
------------------------------------------------------------------------------
Refer the document 'SampleNotificationService.pdf' for how to modify the program 
to suit your environment and run it.

------------------------------------------------------------------------------
6) CONTACT US
------------------------------------------------------------------------------
Questions? Visit the DevNet Finesse Microsite and post your questions in the forums.
    http://developer.cisco.com/site/finesse/