
### TaskActivityNotification Sample Gadgets

These gadgets illustrates usage of Finesse APIs for notifying and receiving updates about Digital Task activity status. It primarily provides a way for Task Management gadgets to inform the desktop and other subscribers about which Tasks is currently active / inactive.

---

#### TaskActivityNotification Publisher Gadget
The gadget is used to publish/notify updates about digital task activity status to subscribers gadgets.

This represent:
```
taskActivityNotification = window.finesse.containerservices.TaskActivityNotification.init(containerServices);

// Publish task
taskActivityNotification.notifyTaskSelection(from, message);
```
Sample Example
```
{
	"from" : "gadget_id",
	"message": {
		"taskId" : "task_id_1",
		"active" : true,
		"mediaType" : "Twitter",
		"timestamp" : 1590419765310 // Date.now()
		"contextInfo" : {
			"twitter_account" : "xyz"
		}
	}
}
```
-  `timestamp` and `contextInfo` are optional fields.
- On click of `Publish` button, JSON payload will be notified to subscriber gadgets.
- On click of `Sample JSON` button, sample JSON will be added to Editor.
---
#### TaskActivityNotification Subscriber Gadget
This gadget is used to receive published digital task activity status.
- Subscribe using callback.
- Request for last task from all the Notifier gadgets.

This represents:
```
taskActivityNotification = window.finesse.containerservices.TaskActivityNotification.init(containerServices);

// subscribe for task
taskActivityNotification.registerForTaskNotifications(callbackFunction);

// request for tasks
taskActivityNotification.requestCurrentTasks()
```
- On click of `Register` button, gadget will register a callback for tasks.
- On click of `Request Tasks` button, gadget will receive last task from notifier gadgets.
- On click of `Clear` button, clear the Editor.

**Note:** Both the sample gadgets `TaskActivityNotificationPublisher.xml` and `TaskActivityNotificationSubscriber.xml` need to be deployed.
