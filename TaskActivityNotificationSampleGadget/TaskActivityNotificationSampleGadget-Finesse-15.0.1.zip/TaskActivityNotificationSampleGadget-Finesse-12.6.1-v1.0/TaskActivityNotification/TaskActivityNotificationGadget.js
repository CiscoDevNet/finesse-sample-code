/**
 * These gadgets illustrates usage of Finesse APIs for notifying and 
 * receiving updates about Digital Task activity status. 
 * It primarily provides a way for Task Management gadgets to inform 
 * the desktop and other subscribers about which Tasks is currently active / inactive.
 */
var finesse = finesse || {};
finesse.gadget = finesse.gadget || {};
finesse.container = finesse.container || {};
clientLogs = finesse.cslogger.ClientLogger || {};

/** @namespace */
finesse.modules = finesse.modules || {};
finesse.modules.TaskActivityNotificationGadget = (function($) {

    var taskActivityNotification = undefined,

    /**
     * Added required click listeners
     */
    _addListeners = function() {
        $("#publishActiveTask").click(_publishActiveTask);
        $("#registerActiveTask").click(_registerActiveTask);
        $("#requestActiveTask").click(_requestActiveTask);
        $("#requestActiveTask").hide();
    },

    /**
     * Method to publish/notify a task selection
     */
    _publishActiveTask = function() {
      try {
        data = editor.get();
        taskActivityNotification.notifyTaskSelection(data.from, data.message);
        $("#failure").hide();
        $("#success").show();
      } catch (err) {
        $("#success").hide();
        $("#failure").show();
        $("#failure").html(err);
      }
    },
    
    /**
     * Method to register for task activity notification
     */
    _registerActiveTask = function() {
        taskActivityNotification.registerForTaskNotifications(_registerActiveTaskCallback);
        $("#requestActiveTask").show();
        $("#registerActiveTask").hide();
    },

    /**
     * Method to request for any task
     */
    _requestActiveTask = function() {
        taskActivityNotification.requestCurrentTasks();
    },

    /**
     * call back method to receive any task
     */
    _registerActiveTaskCallback = function(task) {
        data = editor.get();
        // basic logic to check if already received task is latest. If not, ignore.
        // This is truely business logic to handle multiple task message and choosing the right one.
        if (data.message && data.message.timestamp && parseInt(data.message.timestamp) < parseInt(task.message.timestamp)) {
            editor.set(task);
        } else if (!data.message) {
            // received task object has message object which contains required information about the
            // task activity status like taskId, active, mediaType, timestamp, contenxtInfo
            editor.set(task);
        }
    };

  /** @scope finesse.modules.TaskActivityNotificationGadget */
  return {
        /**
         * Performs all initialization for this gadget
         */
        init: function() {
            var prefs = new gadgets.Prefs(),
                id = prefs.getString("id");
            clientLogs = finesse.cslogger.ClientLogger; // declare clientLogs

            /** Initialize private references */
            utils = finesse.utilities.Utilities;

            finesse.clientservices.ClientServices.init(finesse.gadget.Config);
            clientLogs.init(gadgets.Hub, "ActiveTasks"); //this gadget id will be logged as a part of the message

            containerServices = finesse.containerservices.ContainerServices.init();
            containerServices.addHandler(finesse.containerservices.ContainerServices.Topics.ACTIVE_TAB, function() {
                clientLogs.log("Gadget is now visible"); // log to Finesse logger
            });
            containerServices.makeActiveTabReq();

            //now that the gadget has loaded, remove the loading indicator
            gadgets.loadingindicator.dismiss();

            _addListeners();

            // Task Activity Notification changes
            taskActivityNotification = window.finesse.containerservices.TaskActivityNotification.init(containerServices);
        }
    };
})(jQuery);
