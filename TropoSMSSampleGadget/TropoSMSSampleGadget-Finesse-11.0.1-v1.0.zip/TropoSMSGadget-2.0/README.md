# finesseGadgets
Installation documentation is avilable <a href="https://github.com/bdm1981/finesseGadgets/wiki#tropo-sms-gadget-installation-guide">Here</a>

If you run into any issues/bugs, please add an issues so I can track it.

Send your questions/feedback to bdm@bdmcomputers.com or @bmcallister

Enjoy,

-Brad
