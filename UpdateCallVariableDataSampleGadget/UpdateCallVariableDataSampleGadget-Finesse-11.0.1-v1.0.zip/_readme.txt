****************************************************************************
Cisco Finesse - Update Call Variable Data Sample Gadget
Cisco Systems, Inc.
http://www.cisco.com
https://developer.cisco.com/site/finesse
****************************************************************************

I. Disclaimer
-------------------------------------------------------------------------------

   The Update Call Variable Data Sample Gadget is intended to serve as an
   example of how to use the Update Call Variable Data REST API to change
   the call variable data since that API is not available via the Finesse
   JavaScript API.
      
   This is only a sample and is NOT intended to be a production quality
   gadget and will not be supported as such.  It is NOT guaranteed to
   be bug free. It is merely provided as a guide for a programmer to see
   how to format and pass in the necessary parameters for the
   gadgets.io.makeRequest().
   
   The sample contains the following files:

      FinesseJavaScriptLibrary/
         readme.txt
      UpdateCallVariableData/
         UpdateCallVariableDataSampleGadget.css
         UpdateCallVariableDataSampleGadget.js
         UpdateCallVariableDataSampleGadget.xml
      _readme.txt - This file

   This gadget sample is made available to Cisco partners and customers as
   a convenience to help minimize the cost of Cisco Finesse customizations.
   Please see the readme.txt in the FinesseJavaScriptLibrary folder for
   futher information about the Finesse libraries.


II. Requirements
-------------------------------------------------------------------------------

A call where the call variable data can be updated.


III. Usage
-------------------------------------------------------------------------------

1. Upload the gadget to a web server (third party or Finesse).
2. Add the gadget to the desktop layout.
3. Login an agent.
4. Make a call to the agent where the call variables can be updated.
5. Put some text in one of the call variable input fields and click the button.